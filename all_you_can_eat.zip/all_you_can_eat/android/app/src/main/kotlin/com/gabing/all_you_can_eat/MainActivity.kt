package com.gabing.all_you_can_eat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
